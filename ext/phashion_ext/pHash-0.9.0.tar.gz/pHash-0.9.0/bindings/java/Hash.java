abstract class Hash
{
	String filename;
}
