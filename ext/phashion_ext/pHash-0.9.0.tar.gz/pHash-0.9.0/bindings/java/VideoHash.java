public class VideoHash extends Hash
{
	long[] hash;
}
