public class TextHash extends Hash
{
	String[] hash;
}
