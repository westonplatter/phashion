abstract class ImageHash extends Hash
{
}
