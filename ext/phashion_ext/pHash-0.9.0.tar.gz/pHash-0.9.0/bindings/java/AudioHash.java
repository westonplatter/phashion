public class AudioHash extends Hash
{
	int[] hash;	
}
