public class DCTImageHash extends ImageHash
{
	long hash;
}
