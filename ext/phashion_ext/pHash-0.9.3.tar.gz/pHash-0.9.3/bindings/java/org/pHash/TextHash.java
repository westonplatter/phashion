public class TextHash extends Hash
{
	public String[] hash;
}
