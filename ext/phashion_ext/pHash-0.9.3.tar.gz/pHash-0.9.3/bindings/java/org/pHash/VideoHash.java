public class VideoHash extends Hash
{
	public long[] hash;
}
