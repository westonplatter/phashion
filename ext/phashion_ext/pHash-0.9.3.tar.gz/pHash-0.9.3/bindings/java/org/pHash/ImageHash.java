public abstract class ImageHash extends Hash
{
}
