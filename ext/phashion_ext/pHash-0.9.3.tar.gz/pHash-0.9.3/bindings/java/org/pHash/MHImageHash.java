public class MHImageHash extends ImageHash
{
	byte[] hash;
}
