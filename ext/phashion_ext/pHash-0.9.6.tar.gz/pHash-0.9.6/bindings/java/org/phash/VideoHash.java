package org.phash;
public class VideoHash extends Hash
{
	public long[] hash;
}
