package org.phash;
public class MHImageHash extends ImageHash
{
	public byte[] hash;
}
