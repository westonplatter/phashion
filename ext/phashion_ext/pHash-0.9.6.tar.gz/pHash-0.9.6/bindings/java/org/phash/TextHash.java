package org.phash;
public class TextHash extends Hash
{
	public String[] hash;
}
