package org.phash;

public class RadialImageHash extends ImageHash {
	
	public byte[] hash;
}
